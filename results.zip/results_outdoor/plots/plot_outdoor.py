#!/usr/bin/env python3
"""
Plots and radio calculations for the outdoor link tests (20 November).

Usage: python3 results_outdoor/plots/plot_outdoor.py
Writes PNG + PDF next to this script, plus radio_calculations.txt:
  outdoor_positions, test_positions (indoor and outdoor maps, one image),
  outdoor_delivery_rssi, outdoor_rtt, outdoor_delivered_vs_offered,
  outdoor_path_loss.

Setup: the base station (Raspberry Pi with the Adaptive AgroTech board, echo
device) stayed in place. The laptop with a T-Beam moved to each test position
and ran the tests. For 955-1115 m, a second T-Beam stood at the 880 m
position as a relay. The test ended at 1115 m (no more time).

Data (results_outdoor/):
  latency_summary.csv          one row per latency run (20 pings)
  latency_<label>_<time>.csv   one row per ping (RTT, RSSI, SNR, hops)
  throughput_summary.csv       one row per throughput ramp step
  Untitled map project.kml     base station and test positions (Google Earth)
Labels are the straight-line distance to the base station, from the KML,
rounded to 5 m; "_r" = with the relay. The 400m and 650m tests are left out
(too close to the other positions). The common style (colours, map key, axes)
comes from the indoor plot script, so the indoor and outdoor figures match.
The figures have no titles or notes; those go in the captions in the report.
"""

import csv
import glob
import math
import os
import re
import statistics
import sys
import xml.etree.ElementTree as ET

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..')
sys.path.insert(0, os.path.join(HERE, '..', '..', 'results_indoor', 'plots'))
import plot_indoor as base  # noqa: E402  (common style, helpers, indoor map)

import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

SURFACE, TEXT, MUTED, GRID = base.SURFACE, base.TEXT, base.MUTED, base.GRID
DIRECT, RELAYED, PATHS, FIG_W = base.DIRECT, base.RELAYED, base.PATHS, base.FIG_W
SENSITIVITY_DBM = base.SENSITIVITY_DBM      # -120 dBm, SF7 / 250 kHz
MINUS = '−'

KML = os.path.join(DATA, 'Untitled map project.kml')
ROUTE_CLEAN = os.path.join(HERE, 'outdoor_route_clean.png')   # pins and labels removed

# Test label -> KML placemark. The labels were renamed to these distances.
# Not used: 400m and 650m (too close to the other positions).
POSITIONS = {
    '100m': '100m', '185m': '200m', '350m': '300m', '605m': '450m', '750m': '600m',
    '880m': '750m', '955m_r': '900m', '1040m_r': '1000m', '1115m_r': '1200m',
}
RELAY_AT = '880m'            # the relay T-Beam stood at this test position
# Local metres (east, north, 1) relative to the base station -> pixels in the
# route image. Fitted to the 8 pins the labels do not cover (residual < 0.5 px).
ROUTE_FIT = ((0.497168, 0.010626), (0.010279, -0.499242), (261.0046, 616.7269))
ROUTE_PX_PER_M = 0.498

# Radio settings for the calculations (Meshtastic EU_868, SHORT_FAST).
FREQ_HZ = 869.525e6          # one 250 kHz channel, 869.40-869.65 MHz
ANTENNA_HEIGHT_M = 1.0       # assumed for both ends (held by hand / on a table)
C = 299792458.0


def load_kml():
    ns = {'k': 'http://www.opengis.net/kml/2.2'}
    points = {}
    for pm in ET.parse(KML).getroot().iter('{http://www.opengis.net/kml/2.2}Placemark'):
        lon, lat, _ = [float(v) for v in
                       pm.find('k:Point/k:coordinates', ns).text.strip().split(',')]
        points[pm.find('k:name', ns).text] = (lat, lon)
    return points


def haversine(a, b):
    r = 6371008.8
    p1, p2 = math.radians(a[0]), math.radians(b[0])
    dp, dl = p2 - p1, math.radians(b[1] - a[1])
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


KML_POINTS = load_kml()
BASE = KML_POINTS['Base Station']
RELAY = KML_POINTS[POSITIONS[RELAY_AT]]
DIST = {label: haversine(BASE, KML_POINTS[kml]) for label, kml in POSITIONS.items()}
LABELS = list(POSITIONS)


def via_relay(label):
    return label.endswith('_r')


HOP = {label: haversine(RELAY, KML_POINTS[POSITIONS[label]])   # relay -> laptop
       for label in LABELS if via_relay(label)}
TICKS = [f'{base.round5(DIST[label])}' + ('\nrelay' if via_relay(label) else '')
         for label in LABELS]


def route_px(kml_name):
    lat, lon = KML_POINTS[kml_name]
    east = (lon - BASE[1]) * 111320 * math.cos(math.radians(BASE[0]))
    north = (lat - BASE[0]) * 110574
    (a, b), (c, d), (e, f) = ROUTE_FIT
    return east * a + north * c + e, east * b + north * d + f


def metres(label):
    return f'{base.round5(DIST[label])} m'


def hop_path(hops):
    return 'relayed' if hops not in ('', '0') else 'direct'


def load_runs():
    """Latency runs from the summary. Runs stopped early (< 20 pings) are left out."""
    runs = []
    with open(os.path.join(DATA, 'latency_summary.csv'), newline='') as f:
        for r in csv.DictReader(f):
            if r['label'] in POSITIONS and int(r['sent']) >= 20:
                runs.append({'label': r['label'], 'sent': int(r['sent']),
                             'answered': int(r['answered']),
                             'pdr': int(r['answered']) / int(r['sent']),
                             'path': 'relayed' if via_relay(r['label']) else 'direct'})
    return runs


def load_pings():
    """Answered pings from the per-ping files. Path from the hop count of the pong."""
    pings = []
    for path in sorted(glob.glob(os.path.join(DATA, 'latency_*_2026*.csv'))):
        label = re.match(r'latency_(.+)_\d{8}-\d{6}\.csv$', os.path.basename(path)).group(1)
        if label not in POSITIONS:
            continue
        with open(path, newline='') as f:
            for r in csv.DictReader(f):
                if r['status'] == 'ok':
                    pings.append({'label': label, 'rtt': float(r['rtt_ms']) / 1000.0,
                                  'rssi': float(r['rssi']) if r['rssi'] else None,
                                  'snr': float(r['snr']) if r['snr'] else None,
                                  'path': hop_path(r['hops'])})
    return pings


def load_steps():
    """Throughput ramp steps that got a report from the echo device.

    Delivered = the measured goodput (as indoors): bytes received over the time
    from the first to the last arrival; offered x delivery ratio if < 2 arrived.
    """
    steps = []
    with open(os.path.join(DATA, 'throughput_summary.csv'), newline='') as f:
        for r in csv.DictReader(f):
            if r['status'] != 'ok' or r['label'] not in POSITIONS or not r['received']:
                continue
            offered, pdr = float(r['offered_Bps']), float(r['pdr'])
            goodput = float(r['goodput_Bps']) if r['goodput_Bps'] else offered * pdr
            steps.append({'label': r['label'], 'offered': offered, 'pdr': pdr,
                          'delivered': goodput,
                          'path': 'relayed' if via_relay(r['label']) else hop_path(r['hops'])})
    return steps


def save(fig, stem):
    base.save(fig, stem, HERE)


# --- maps ---------------------------------------------------------------------


def draw_route(fig, rect, crop, fs=base.MAP_FS):
    """Satellite view of the route with the base station, positions and relay."""
    ax = base.map_image(fig, rect, ROUTE_CLEAN, crop)
    points = {metres(label): route_px(kml) for label, kml in POSITIONS.items()}
    relayed = [metres(label) for label in LABELS if via_relay(label)]
    # Direct link: the tests without the relay (indoors, 75 m also had a direct test).
    base.draw_marks(ax, route_px('Base Station'), points, relay=metres(RELAY_AT),
                    direct=[p for p in points if p not in relayed], hops=relayed,
                    left={metres(label) for label in ('605m', '750m', '880m', '1040m_r')},
                    fs=fs)
    base.scale_bar(ax, crop[0] + 18, 636, 200 * ROUTE_PX_PER_M, '200 m')
    return ax


ROUTE_CROP = (78, 433, 25, 650)                      # x0, x1, y0, y1 shown alone
ROUTE_ASPECT = (ROUTE_CROP[1] - ROUTE_CROP[0]) / (ROUTE_CROP[3] - ROUTE_CROP[2])


def plot_positions():
    rows = []
    for label in LABELS:
        path = ('via relay' if label == '1115m_r' else 'direct and via relay'
                if via_relay(label) else 'direct; relay here' if label == RELAY_AT
                else 'direct')
        hop = f'{base.round5(HOP[label])} m' if label in HOP else '–'
        rows.append((metres(label), path, hop))
    base.map_with_table(lambda fig, rect: draw_route(fig, rect, ROUTE_CROP), ROUTE_ASPECT,
                        rows, 'outdoor_positions', HERE)


def plot_both_maps():
    """Indoor and outdoor maps side by side in one image, as (a) and (b), one key."""
    crop = (0, 433, 25, 650)                         # whole route image width
    out_aspect = (crop[1] - crop[0]) / (crop[3] - crop[2])
    gap = 0.35
    map_h = (FIG_W - gap) / (base.PLAN_ASPECT + out_aspect)
    plan_w, out_w = base.PLAN_ASPECT * map_h, out_aspect * map_h
    key_h, title_h = 0.75, 0.3
    total = key_h + map_h + title_h
    fig = plt.figure(figsize=(FIG_W, total))
    title_y = (key_h + map_h + 0.07) / total

    base.draw_indoor(fig, base.inches(fig, 0, key_h, plan_w, map_h))
    fig.text(0, title_y, '(a) Indoor', fontsize=10, fontweight='semibold', color=TEXT,
             va='bottom')
    left = plan_w + gap
    draw_route(fig, base.inches(fig, left, key_h, out_w, map_h), crop)
    fig.text(left / FIG_W, title_y, '(b) Outdoor', fontsize=10, fontweight='semibold',
             color=TEXT, va='bottom')
    x_sep = (plan_w + gap / 2) / FIG_W
    fig.add_artist(Line2D([x_sep, x_sep], [(key_h + 0.02) / total, 0.98], color=GRID,
                          linewidth=1))

    key = fig.add_axes(base.inches(fig, 0, 0, FIG_W, key_h))
    key.axis('off')
    key.set_xlim(0, FIG_W)
    key.set_ylim(0, key_h)
    base.key_column(key, base.MAP_KEY[:3], 0, key_h - 0.15)
    base.key_column(key, base.MAP_KEY[3:], left, key_h - 0.15)
    save(fig, 'test_positions')
    print(f'  maps {map_h:.2f} in high; indoor {plan_w:.2f} in, outdoor {out_w:.2f} in wide')


# --- result plots -------------------------------------------------------------


def draw_by_position(ax, items, key, ylabel, ylim, bar=0.15, fmt=None, label_fs=7.5,
                     ref=None, size=30):
    """Points per position (x = category); median bar per position and path."""
    for x, label in enumerate(LABELS):
        sub = [it for it in items if it['label'] == label and it[key] is not None]
        paths = [p for p in PATHS if any(it['path'] == p for it in sub)]
        for k, path in enumerate(paths):
            group = [it for it in sub if it['path'] == path]
            centre = x + (0 if len(paths) == 1 else (-0.17 if k == 0 else 0.17))
            width = 0.3 if len(paths) == 1 else 0.16
            for i, it in enumerate(group):
                # Even spread in measurement order (golden-ratio sequence), not by value.
                offset = 0.0 if len(group) == 1 else ((i * 0.618034) % 1 - 0.5) * width
                value = it[key]
                if value > ylim[1]:          # off the scale: draw at the top, give the value
                    value = ylim[1] - (ylim[1] - ylim[0]) * 0.03
                    ax.annotate(f'{fmt(it[key]) if fmt else it[key]} ↑',
                                (centre + offset, value), fontsize=label_fs, color=TEXT,
                                ha='left', va='center', xytext=(5, 0),
                                textcoords='offset points')
                base.dot(ax, centre + offset, value, path, size=size)
            med = statistics.median(it[key] for it in group)
            half = bar if len(paths) == 1 else bar * 0.6
            ax.plot([centre - half, centre + half], [med, med], color=TEXT, linewidth=2,
                    solid_capstyle='round', zorder=4)
            if fmt:
                # Left group of a shared position: label on the left, clear of the right group.
                left = len(paths) > 1 and k == 0
                ax.annotate(fmt(med).replace('-', MINUS),
                            (centre - half if left else centre + half, med), va='center',
                            ha='right' if left else 'left', fontsize=label_fs, color=TEXT,
                            xytext=(-2 if left else 2, 0), textcoords='offset points')
    if ref is not None:
        ax.axhline(ref, color=MUTED, linewidth=1, zorder=1)
    base.category_axis(ax, TICKS)
    ax.set_ylim(*ylim)
    ax.set_ylabel(ylabel)


def plot_delivery_and_rssi(runs, pings):
    def panel_a(ax):
        draw_by_position(ax, runs, 'pdr', 'Pings answered', base.PDR_YLIM)
        ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))

    base.plot_pair(
        panel_a,
        lambda ax: draw_by_position(ax, pings, 'rssi', 'RSSI (dBm)', base.RSSI_YLIM,
                                    ref=SENSITIVITY_DBM),
        '(a) Pings answered', '(b) Received signal strength (RSSI)',
        'outdoor_delivery_rssi', HERE)


def plot_rtt(pings):
    fig, ax = plt.subplots(figsize=(FIG_W, 3.3))
    draw_by_position(ax, pings, 'rtt', 'Round-trip time (s)', (0, 5.2),
                     fmt=lambda v: f'{v:.1f}', label_fs=7, size=34)
    ax.legend(handles=base.path_handles() + [base.median_handle('Median (s)')],
              loc='upper left')
    fig.tight_layout()
    save(fig, 'outdoor_rtt')


def plot_delivered_vs_offered(steps):
    labels = [label for label in LABELS if any(s['label'] == label for s in steps)]
    names = {label: metres(label) + (' (relay)' if via_relay(label) else '')
             for label in labels}
    base.plot_delivered_grid(steps, labels, names, 4, 'outdoor_delivered_vs_offered', HERE)


# --- radio calculations -------------------------------------------------------


def fspl_db(d_m):
    return 20 * math.log10(4 * math.pi * d_m * FREQ_HZ / C)


def two_ray_db(d_m, ht=ANTENNA_HEIGHT_M, hr=ANTENNA_HEIGHT_M):
    """Plane-earth two-ray path loss; free space below the crossover distance."""
    if d_m < 4 * math.pi * ht * hr * FREQ_HZ / C:
        return fspl_db(d_m)
    return 40 * math.log10(d_m) - 20 * math.log10(ht * hr)


def fit_log_distance(points, d0=100.0):
    """Least-squares fit of RSSI = A - 10 n log10(d / d0). Returns (A, n)."""
    xs = [math.log10(d / d0) for d, _ in points]
    ys = [rssi for _, rssi in points]
    mx, my = statistics.fmean(xs), statistics.fmean(ys)
    slope = sum((x - mx) * (y - my) for x, y in zip(xs, ys)) / sum((x - mx) ** 2 for x in xs)
    return my - slope * mx, -slope / 10


def medians_by_path(pings, path, distance, min_pings=5):
    """(distance, median RSSI, pongs, enough pongs) per position for one pong path."""
    out = []
    for label in LABELS:
        vals = [p['rssi'] for p in pings if p['label'] == label and p['path'] == path
                and p['rssi'] is not None]
        if vals and label in distance:
            out.append((distance[label], statistics.median(vals), len(vals),
                        len(vals) >= min_pings))
    return out


def plot_path_loss(pings):
    points = medians_by_path(pings, 'direct', DIST)
    hops = medians_by_path(pings, 'relayed', HOP)
    fit_points = [(d, r) for d, r, _, used in points if used]
    a, n = fit_log_distance(fit_points)
    resid = [r - (a - 10 * n * math.log10(d / 100)) for d, r in fit_points]
    sigma = statistics.pstdev(resid)
    d_max = 100 * 10 ** ((a - SENSITIVITY_DBM) / (10 * n))
    d0, ref = points[0][0], points[0][1]

    fig, ax = plt.subplots(figsize=(FIG_W, 3.6))
    ds = [10 ** (1.75 + i * 0.01) for i in range(int((3.5 - 1.75) / 0.01) + 1)]
    ax.plot(ds, [ref - (fspl_db(d) - fspl_db(d0)) for d in ds], color=MUTED, linewidth=1.2,
            linestyle=(0, (1.5, 1.5)), label='Free space (n = 2)', zorder=2)
    ax.plot(ds, [ref - (two_ray_db(d) - two_ray_db(d0)) for d in ds], color=base.TEXT_2,
            linewidth=1.2, linestyle=(0, (4, 2)),
            label='Two-ray ground reflection, antennas 1 m high (n = 4)', zorder=2)
    ax.plot(ds, [a - 10 * n * math.log10(d / 100) for d in ds], color=DIRECT, linewidth=1.8,
            label=f'Fit to the direct links (n = {n:.1f})', zorder=2)
    ax.axhline(SENSITIVITY_DBM, color=MUTED, linewidth=1, zorder=1)
    few = []
    for d, rssi, count, used in points:
        if used:
            base.dot(ax, d, rssi, 'direct', size=44)
        else:
            few.append(count)
            ax.scatter(d, rssi, s=44, facecolors=SURFACE, edgecolors=DIRECT, linewidths=1.4,
                       zorder=3)
    for d, rssi, _, _ in hops:
        base.dot(ax, d, rssi, 'relayed', size=44)
    ax.set_xscale('log')
    ax.set_xlim(60, 3000)
    ax.set_ylim(-140, -40)
    ax.xaxis.set_major_locator(matplotlib.ticker.FixedLocator([100, 200, 500, 1000, 2000]))
    ax.xaxis.set_minor_formatter(matplotlib.ticker.NullFormatter())
    ax.xaxis.set_major_formatter(matplotlib.ticker.FuncFormatter(lambda v, _: f'{v:g}'))
    ax.set_xlabel('Link distance (m, log scale)')
    ax.set_ylabel('Median RSSI (dBm)')
    handles, labels = ax.get_legend_handles_labels()
    handles += [base.ref_handle()] + base.path_handles()
    labels += ['Receiver sensitivity', 'Direct link', 'Relay hop (not in fit)']
    if few:
        handles.append(Line2D([], [], linestyle='', marker='o', markersize=7,
                              markerfacecolor=SURFACE, markeredgecolor=DIRECT))
        labels.append(f'Direct link, {few[0]} pongs (not in fit)')
    ax.legend(handles, labels, loc='upper right', fontsize=7.5)
    fig.tight_layout()
    save(fig, 'outdoor_path_loss')
    return {'A': a, 'n': n, 'sigma': sigma, 'd_max': d_max, 'points': points, 'hops': hops}


def dbm_to_uv(dbm, ohm=50.0):
    return math.sqrt(10 ** (dbm / 10) * 1e-3 * ohm) * 1e6


def write_calculations(fit):
    lam = C / FREQ_HZ
    crossover = 4 * math.pi * ANTENNA_HEIGHT_M ** 2 / lam
    a, n = fit['A'], fit['n']
    lines = [
        'Radio calculations, outdoor tests 20 November (Meshtastic EU_868, SHORT_FAST)',
        '=' * 78,
        'Base station: Raspberry Pi + Adaptive AgroTech board (own antenna), fixed.',
        'Moving: laptop + T-Beam. Relay: T-Beam at the 880 m position (955-1115 m tests).',
        f'Frequency {FREQ_HZ / 1e6:.3f} MHz, wavelength {lam:.3f} m. '
        f'Receiver sensitivity {SENSITIVITY_DBM} dBm (SF7, 250 kHz).',
        f'Antenna height {ANTENNA_HEIGHT_M:.0f} m at both ends (assumed). '
        f'Two-ray crossover distance 4*pi*ht*hr/lambda = {crossover:.0f} m.',
        '',
        'Log-distance fit to the median RSSI of direct pongs (positions with >= 5 pongs):',
        f'  RSSI(d) = {a:.1f} dBm - 10 * {n:.2f} * log10(d / 100 m)',
        f'  path-loss exponent n = {n:.2f}; residual standard deviation {fit["sigma"]:.1f} dB',
        f'  the fit reaches {SENSITIVITY_DBM} dBm at {fit["d_max"]:.0f} m',
        '  Note: near the range limit only the stronger packets arrive, so the median of',
        '  the received RSSI is too high there and n is slightly too low.',
        '',
        '  Distance  Pongs  Measured  Fit     Margin   FSPL     Fresnel r1',
        '  (m)              (dBm)     (dBm)   (dB)     (dB)     mid-path (m)',
    ]
    for d, rssi, count, used in fit['points']:
        model = a - 10 * n * math.log10(d / 100)
        r1 = math.sqrt(lam * d / 4)
        lines.append(f'  {d:7.0f}  {count:5d}{" " if used else "*"}{rssi:8.1f}  {model:6.1f}  '
                     f'{rssi - SENSITIVITY_DBM:6.1f}  {fspl_db(d):7.1f}  {r1:9.1f}')
    lines += [
        '  * not in the fit (too few direct pongs). Margin = measured RSSI - sensitivity.',
        '  FSPL = free-space path loss. Fresnel r1 = radius of the first Fresnel zone at',
        '  mid-path. With the antennas 1 m high, r1 is 3-9 times the antenna height, so',
        '  the ground blocks a large part of the zone on every link. This gives the',
        '  extra loss above free space and the fast drop in RSSI with distance.',
        '',
        'Excess loss over free space (loss growth from 100 m, minus FSPL growth):',
    ]
    d0, r0 = fit['points'][0][0], fit['points'][0][1]
    for d, rssi, _, _ in fit['points'][1:]:
        excess = (r0 - rssi) - (fspl_db(d) - fspl_db(d0))
        lines.append(f'  {d:7.0f} m  {excess:5.1f} dB')
    lines += ['', 'Relay hops (relay at the 880 m position to the laptop), relayed pongs:']
    for d, rssi, count, _ in fit['hops']:
        lines.append(f'  hop {d:4.0f} m  {count:2d} pongs  median {rssi:6.1f} dBm  '
                     f'margin {rssi - SENSITIVITY_DBM:5.1f} dB')
    lines += [
        '  The relay to base station hop is 880 m long: the same path as the 880 m direct',
        '  test (median -118 dBm), so this hop sets the limit of the relayed link.',
        '',
        'Inputs for Radio Mobile Online (https://www.ve2dbe.com/rmonline_s.asp)',
        '-' * 78,
        f'  Frequency            {FREQ_HZ / 1e6 - 0.125:.3f} - {FREQ_HZ / 1e6 + 0.125:.3f} MHz',
        '  Transmit power       [CHECK] (SX1262 maximum 22 dBm = 0.16 W; SX1276 20 dBm)',
        '  Antenna gain         [CHECK] dBi: T-Beam stock whip about 2 dBi; AgroTech antenna',
        '  Line loss            0.5 dB',
        f'  Antenna height       {ANTENNA_HEIGHT_M:.0f} m (all sites) [CHECK]',
        f'  Receiver threshold   {SENSITIVITY_DBM} dBm = {dbm_to_uv(SENSITIVITY_DBM):.2f} uV '
        '(50 ohm)',
        '  Radio climate        Continental temperate; polarization vertical',
        '  Sites (latitude, longitude, WGS84):',
    ]
    for label in ['Base station'] + LABELS:
        lat, lon = KML_POINTS['Base Station' if label == 'Base station' else POSITIONS[label]]
        name = label if label == 'Base station' else metres(label)
        if label == RELAY_AT:
            name += ' + relay'
        lines.append(f'    {name:16} {lat:.6f}  {lon:.6f}')
    lines += ['  Links to run: base station to each position; relay (880 m) to 955, 1040 and',
              '  1115 m.']
    path = os.path.join(HERE, 'radio_calculations.txt')
    with open(path, 'w') as f:
        f.write('\n'.join(lines) + '\n')
    print('wrote', os.path.basename(path))


def main():
    runs, pings, steps = load_runs(), load_pings(), load_steps()
    print(f'{len(runs)} latency runs, {len(pings)} answered pings, {len(steps)} throughput steps')
    plot_positions()
    plot_both_maps()
    plot_delivery_and_rssi(runs, pings)
    plot_rtt(pings)
    plot_delivered_vs_offered(steps)
    write_calculations(plot_path_loss(pings))


if __name__ == '__main__':
    main()
