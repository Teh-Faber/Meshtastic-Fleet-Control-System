#!/usr/bin/env python3
"""
Plots for the indoor link tests, and the common style for all test figures.

Usage: python3 results_indoor/plots/plot_indoor.py
Writes PNG + PDF next to this script:
  indoor_map, indoor_delivery_rssi, indoor_delivered_vs_offered,
  indoor_delivery, indoor_rssi, indoor_snr.
results_outdoor/plots/plot_outdoor.py makes the outdoor figures and the
combined map (test_positions) with the helpers here, so all figures match:
the same colours, markers, map key, axis ranges and distance axis. The
figures have no titles or notes; those go in the figure captions in the report.

Each ramp step is one point. "Delivered" is the measured goodput: bytes
received over the time from the first to the last arrival. When fewer than
2 messages arrived there is no goodput, and offered rate x delivery ratio is
used instead.
"""

import csv
import math
import os
import statistics

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt  # noqa: E402
import matplotlib.ticker  # noqa: E402
from matplotlib.lines import Line2D  # noqa: E402

HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', 'indoors_throughput_summary.csv')

# Test label in the CSV -> tick label on the distance axis and panel name.
# The labels are the straight-line distance to the base station (the Pi)
# measured on the floor plan, rounded to 5 m; "_r" = via the relay. (The tests
# were first labelled 20m/50m/100m; indoors_throughput_summary.orig.csv has those.)
LOCATIONS = {'1m': '1', '25m': '25', '65m': '65', '75m': '75', '75m_r': '75\nrelay'}
NAMES = {'1m': '1 m', '25m': '25 m', '65m': '65 m', '75m': '75 m', '75m_r': '75 m (relay)'}

# Floor plan (indoor_floorplan_blank.png) and the marked positions, in pixels.
FLOORPLAN = os.path.join(HERE, 'indoor_floorplan_blank.png')
WALL_PX = ((108, 155), (152, 805))   # outer wall on the long side ...
WALL_M = 113.0                        # ... is about 113 m long
PI_PX = (477, 577)                    # base station
POSITIONS_PX = {                      # CSV label -> marker position
    '25m': (446, 449),
    '65m': (429, 208),                # also where the relay stood
    '75m': (253, 220),                # 75m and 75m_r
}
PLAN_CROP = (95, 565, 115, 830)       # x0, x1, y0, y1 shown

# Reference palette (dataviz skill), light mode. Slots 1-2 validate
# all-pairs; path is also encoded by marker shape.
SURFACE = '#fcfcfb'
TEXT = '#0b0b0b'
TEXT_2 = '#52514e'
MUTED = '#8a8984'
GRID = '#e6e5e1'
DIRECT = '#2a78d6'   # slot 1, blue
RELAYED = '#eb6834'  # slot 2, orange
PATHS = {'direct': (DIRECT, 'o', 'Direct'), 'relayed': (RELAYED, '^', 'Via relay (1 hop)')}

# The report's web interface shows every image at the full text width
# (about 7 in) and the size can't be changed, so the figures are drawn at that
# width: text then prints at its real size, and the height is chosen here.
FIG_W = 7.0

SENSITIVITY_DBM = -120   # approx. receiver sensitivity, SF7 / 250 kHz
SNR_LIMIT_DB = -7.5      # LoRa demodulation limit at SF7

# Common axes for the indoor and outdoor result figures.
DISTANCE_LABEL = 'Distance to base station (m)'
PDR_YLIM = (-0.05, 1.08)
RSSI_YLIM = (-130, -30)

# Common map style.
MAP_KEY = [('s', TEXT, 'Base station: Raspberry Pi with echo device'),
           ('o', DIRECT, 'Test position: laptop with T-Beam'),
           ('^', RELAYED, 'Relay: T-Beam'),
           ('line', DIRECT, 'Direct link'),
           ('line', RELAYED, 'Relay hop')]
MARK_SIZE = {'base': 90, 'position': 60, 'relay': 110}
LINK_W = 1.6
MAP_FS = 8

plt.rcParams.update({
    'figure.facecolor': SURFACE, 'axes.facecolor': SURFACE, 'savefig.facecolor': SURFACE,
    'font.family': 'DejaVu Sans', 'font.size': 9,
    'text.color': TEXT, 'axes.labelcolor': TEXT_2, 'xtick.color': TEXT_2, 'ytick.color': TEXT_2,
    'axes.edgecolor': GRID, 'axes.linewidth': 1.0,
    'axes.grid': True, 'grid.color': GRID, 'grid.linewidth': 0.8, 'grid.linestyle': '-',
    'axes.spines.top': False, 'axes.spines.right': False,
    'axes.titlesize': 10, 'axes.titleweight': 'semibold', 'axes.titlecolor': TEXT,
    'legend.frameon': False, 'legend.fontsize': 8,
})


# --- common helpers -------------------------------------------------------------


def save(fig, name, folder=HERE):
    for ext in ('png', 'pdf'):
        fig.savefig(os.path.join(folder, f'{name}.{ext}'), dpi=200, bbox_inches='tight')
    plt.close(fig)
    print('wrote', name)


def inches(fig, left, bottom, width, height):
    """Axes rectangle from inches (origin bottom left) to figure fractions."""
    w, h = fig.get_size_inches()
    return [left / w, bottom / h, width / w, height / h]


def round5(m):
    return int(5 * math.floor(m / 5 + 0.5))


def dot(ax, x, y, path, size=30):
    color, marker, _ = PATHS[path]
    if marker == '^':
        size *= 1.5  # a triangle covers less area than a circle of the same size
    ax.scatter(x, y, s=size, c=color, marker=marker, edgecolors=SURFACE, linewidths=1.4,
               zorder=3)


def jitter(i, n, width=0.22):
    return 0.0 if n <= 1 else (i / (n - 1) - 0.5) * width


def path_handles(paths=('direct', 'relayed')):
    return [Line2D([], [], linestyle='', marker=PATHS[p][1], markersize=7,
                   markerfacecolor=PATHS[p][0], markeredgecolor=SURFACE, label=PATHS[p][2])
            for p in paths]


def median_handle(text='Median'):
    return Line2D([], [], color=TEXT, linewidth=2, solid_capstyle='round', label=text)


def ref_handle(text='Receiver sensitivity'):
    return Line2D([], [], color=MUTED, linewidth=1, label=text)


def key_row(ax, items, y, x=0.0, fs=8):
    """Horizontal key in inch coordinates: (kind, colour, text); kind is a marker,
    'line' (thin line) or 'bar' (median bar)."""
    for kind, color, text in items:
        if kind == 'line':
            ax.plot([x, x + 0.22], [y, y], color=color, linewidth=1.6 if color != MUTED else 1)
        elif kind == 'bar':
            ax.plot([x, x + 0.22], [y, y], color=color, linewidth=2, solid_capstyle='round')
        else:
            ax.scatter(x + 0.11, y, s=45 if kind != '^' else 60, marker=kind, c=color,
                       edgecolors=SURFACE, linewidths=1.3)
        ax.text(x + 0.32, y, text, fontsize=fs, color=TEXT, va='center')
        x += 0.32 + len(text) * fs * 0.58 / 72 + 0.3
    return x


def key_column(ax, items, x, y, step=0.21, fs=8):
    """Vertical key in inch coordinates; returns the y below the last row."""
    for kind, color, text in items:
        if kind == 'line':
            ax.plot([x, x + 0.22], [y, y], color=color, linewidth=LINK_W)
        else:
            ax.scatter(x + 0.11, y, s=45 if kind != '^' else 60, marker=kind, c=color,
                       edgecolors=SURFACE, linewidths=1.3)
        ax.text(x + 0.32, y, text, fontsize=fs, color=TEXT, va='center')
        y -= step
    return y


def lighten(img):
    """Greyscale, lightened, so the measurement marks stand out."""
    gray = img[..., :3] @ [0.299, 0.587, 0.114]
    return 0.55 + 0.45 * gray


def label_box():
    return dict(boxstyle='round,pad=0.2', fc=SURFACE, ec=GRID, lw=0.6, alpha=0.95)


def scale_bar(ax, x0, y0, px, text):
    ax.plot([x0, x0 + px], [y0, y0], color=TEXT, linewidth=2.5, solid_capstyle='butt',
            zorder=7)
    ax.text(x0 + px / 2, y0 - 7, text, ha='center', va='bottom', fontsize=MAP_FS, color=TEXT,
            zorder=7, bbox=label_box())


def map_image(fig, rect, path, crop):
    ax = fig.add_axes(rect)
    ax.imshow(lighten(plt.imread(path)), cmap='gray', vmin=0, vmax=1, interpolation='lanczos')
    ax.set_xlim(crop[0], crop[1])
    ax.set_ylim(crop[3], crop[2])
    ax.axis('off')
    return ax


def draw_marks(ax, base_xy, points, relay=None, direct=(), hops=(), left=(),
               base_left=False, fs=MAP_FS):
    """Base station, test positions, relay and links, in the common map style.

    points: {label text: (x, y)}; relay: the label where the relay stood;
    direct: labels with a direct link; hops: labels reached through the relay;
    left: labels written on the left of their mark.
    """
    for label in direct:
        x, y = points[label]
        ax.plot([base_xy[0], x], [base_xy[1], y], color=DIRECT, linewidth=LINK_W,
                solid_capstyle='round', zorder=2)
    for label in hops:
        (rx, ry), (x, y) = points[relay], points[label]
        ax.plot([rx, x], [ry, y], color=RELAYED, linewidth=LINK_W, solid_capstyle='round',
                zorder=3)
    ax.scatter(*base_xy, s=MARK_SIZE['base'], marker='s', c=TEXT, edgecolors=SURFACE,
               linewidths=1.6, zorder=6)
    ax.annotate('Base station', base_xy, xytext=(-7 if base_left else 7, 0),
                textcoords='offset points', ha='right' if base_left else 'left',
                va='center', fontsize=fs, color=TEXT, bbox=label_box(), zorder=7)
    for label, xy in points.items():
        if label == relay:
            ax.scatter(*xy, s=MARK_SIZE['relay'], marker='^', c=RELAYED, edgecolors=SURFACE,
                       linewidths=1.6, zorder=6)
        else:
            ax.scatter(*xy, s=MARK_SIZE['position'], c=DIRECT, edgecolors=SURFACE,
                       linewidths=1.6, zorder=6)
        side = -1 if label in left else 1
        ax.annotate(label, xy, xytext=(7 * side, 0), textcoords='offset points',
                    ha='right' if side < 0 else 'left', va='center', fontsize=fs, color=TEXT,
                    bbox=label_box(), zorder=7)


def map_with_table(draw_map, aspect, rows, name, folder=HERE, map_h=4.6):
    """One map, with the map key and a table (distance, path, relay hop) beside it."""
    map_w = map_h * aspect
    fig = plt.figure(figsize=(FIG_W, map_h))
    draw_map(fig, inches(fig, 0, 0, map_w, map_h))
    side_x, side_w = map_w + 0.3, FIG_W - map_w - 0.3
    side = fig.add_axes(inches(fig, side_x, 0, side_w, map_h))
    side.axis('off')
    side.set_xlim(0, side_w)
    side.set_ylim(0, map_h)
    y = key_column(side, MAP_KEY, 0, map_h - 0.15)
    y -= 0.2
    cols = (0, 0.75, 2.3)
    for x, cell in zip(cols, ('Distance', 'Path', 'Relay hop')):
        side.text(x, y, cell, fontsize=8, color=TEXT, fontweight='semibold', va='center')
    side.plot([0, min(side_w, 3.1)], [y - 0.13, y - 0.13], color=GRID, linewidth=0.8)
    y -= 0.29
    for row in rows:
        for x, cell in zip(cols, row):
            side.text(x, y, cell, fontsize=8, color=TEXT, va='center')
        y -= 0.22
    save(fig, name, folder)


def category_axis(ax, ticks):
    """Common distance axis: one category per test, tick labels in metres."""
    ax.set_xticks(range(len(ticks)))
    ax.set_xticklabels(ticks)
    ax.set_xlim(-0.5, len(ticks) - 0.5)
    ax.grid(axis='x', visible=False)
    ax.set_xlabel(DISTANCE_LABEL)


def plot_pair(draw_a, draw_b, title_a, title_b, name, folder=HERE):
    """Two result panels side by side, as (a) and (b), with one key under both."""
    gap, pad = 0.45, 0.55              # gap between panels, room for the y-axis labels
    panel_w = (FIG_W - gap - 2 * pad) / 2
    plot_h, title_h, axis_h, key_h = 2.35, 0.32, 0.68, 0.3
    total = key_h + axis_h + plot_h + title_h
    fig = plt.figure(figsize=(FIG_W, total))
    bottom = key_h + axis_h
    ax_a = fig.add_axes(inches(fig, pad, bottom, panel_w, plot_h))
    draw_a(ax_a)
    x_b = pad + panel_w + gap + pad
    ax_b = fig.add_axes(inches(fig, x_b, bottom, panel_w, plot_h))
    draw_b(ax_b)
    for ax in (ax_a, ax_b):
        ax.tick_params(labelsize=7.5)
        ax.xaxis.label.set_size(8)
    title_y = (bottom + plot_h + 0.1) / total
    fig.text(0, title_y, title_a, fontsize=10, fontweight='semibold', color=TEXT, va='bottom')
    fig.text((x_b - pad) / FIG_W, title_y, title_b, fontsize=10, fontweight='semibold',
             color=TEXT, va='bottom')
    x_sep = (pad + panel_w + gap / 2) / FIG_W
    fig.add_artist(Line2D([x_sep, x_sep], [(key_h + 0.05) / total, 0.98], color=GRID,
                          linewidth=1))
    key = fig.add_axes(inches(fig, 0, 0, FIG_W, key_h))
    key.axis('off')
    key.set_xlim(0, FIG_W)
    key.set_ylim(0, key_h)
    key_row(key, [('o', DIRECT, PATHS['direct'][2]), ('^', RELAYED, PATHS['relayed'][2]),
                  ('bar', TEXT, 'Median'), ('line', MUTED, 'Receiver sensitivity')],
            y=key_h / 2)
    save(fig, name, folder)


def plot_delivered_grid(steps, labels, names, ncols, name, folder=HERE):
    """Delivered vs offered data rate, one panel per test position."""
    fig, grid = plt.subplots(2, ncols, figsize=(FIG_W, 4.5), sharex=True, sharey=True)
    axes = grid.flatten()
    top = max(s['offered'] for s in steps) * 1.08
    for i, (ax, label) in enumerate(zip(axes, labels)):
        ax.plot([0, top], [0, top], color=MUTED, linewidth=1, zorder=1)
        for s in (s for s in steps if s['label'] == label):
            dot(ax, s['offered'], s['delivered'], s['path'], size=32)
        ax.set_title(names[label], loc='left', fontsize=9)
        ax.set_xlim(0, top)
        ax.set_ylim(0, top)
        ax.xaxis.set_major_locator(matplotlib.ticker.MultipleLocator(400))
        ax.yaxis.set_major_locator(matplotlib.ticker.MultipleLocator(400))
        ax.tick_params(labelsize=7.5)
        if i + ncols >= len(labels):          # no panel under this one
            ax.tick_params(labelbottom=True)
            ax.set_xlabel('Offered (B/s)', fontsize=8)
    for ax in grid[:, 0]:
        ax.set_ylabel('Delivered (B/s)', fontsize=8)
    for ax in axes[len(labels):]:
        ax.axis('off')
    present = [p for p in PATHS if any(s['path'] == p for s in steps)]
    axes[len(labels)].legend(handles=path_handles(present) + [ref_handle('All delivered')],
                             loc='center left')
    fig.tight_layout()
    save(fig, name, folder)


# --- indoor data and figures ----------------------------------------------------


def load():
    rows = []
    with open(DATA, newline='') as f:
        for r in csv.DictReader(f):
            if r['status'] != 'ok' or r['label'] not in LOCATIONS:
                continue
            offered = float(r['offered_Bps'])
            pdr = float(r['pdr']) if r['pdr'] else 0.0
            # Hops: '' (sent with hop limit 0) and '0' are direct; >= 1 came through the relay.
            path = 'relayed' if r['hops'] not in ('', '0') else 'direct'
            rows.append({
                'label': r['label'], 'offered': offered, 'pdr': pdr,
                'delivered': float(r['goodput_Bps']) if r['goodput_Bps'] else offered * pdr,
                'path': path,
                'rssi': float(r['rssi_mean']) if r['rssi_mean'] else None,
                'snr': float(r['snr_mean']) if r['snr_mean'] else None,
            })
    return rows


def metres(a, b):
    return math.dist(a, b) * WALL_M / math.dist(*WALL_PX)


INDOOR_POINTS = {f'{round5(metres(PI_PX, xy))} m': xy for xy in POSITIONS_PX.values()}
INDOOR_RELAY = f'{round5(metres(PI_PX, POSITIONS_PX["65m"]))} m'
INDOOR_FAR = f'{round5(metres(PI_PX, POSITIONS_PX["75m"]))} m'
INDOOR_HOP_M = round5(metres(POSITIONS_PX['65m'], POSITIONS_PX['75m']))
PLAN_ASPECT = (PLAN_CROP[1] - PLAN_CROP[0]) / (PLAN_CROP[3] - PLAN_CROP[2])


def draw_indoor(fig, rect, fs=MAP_FS):
    """Floor plan with the base station, test positions and relay."""
    ax = map_image(fig, rect, FLOORPLAN, PLAN_CROP)
    draw_marks(ax, PI_PX, INDOOR_POINTS, relay=INDOOR_RELAY, direct=list(INDOOR_POINTS),
               hops=[INDOOR_FAR], left={'25 m', INDOOR_FAR}, base_left=True, fs=fs)
    scale_bar(ax, 115, 812, 20 * math.dist(*WALL_PX) / WALL_M, '20 m')
    return ax


def plot_map():
    rows = [('1 m', 'direct', '–')]
    paths = {'25m': 'direct', '65m': 'direct; relay here', '75m': 'direct and via relay'}
    for label, xy in POSITIONS_PX.items():
        hop = f'{INDOOR_HOP_M} m' if label == '75m' else '–'
        rows.append((f'{round5(metres(PI_PX, xy))} m', paths[label], hop))
    map_with_table(draw_indoor, PLAN_ASPECT, rows, 'indoor_map')
    for label, xy in POSITIONS_PX.items():
        print(f'  {label}: {metres(PI_PX, xy):.1f} m')
    print(f'  relay hop: {metres(POSITIONS_PX["65m"], POSITIONS_PX["75m"]):.1f} m')


def draw_strip(ax, rows, key, ylabel, ylim, ref=None, fmt=None, percent=False, bar=0.15,
               size=30, label_fs=7.5):
    """One dot per ramp step for each test, with the median as a bar (and value with fmt)."""
    labels = list(LOCATIONS)
    for x, label in enumerate(labels):
        sub = [r for r in rows if r['label'] == label and r[key] is not None]
        for i, r in enumerate(sorted(sub, key=lambda r: r['offered'])):
            dot(ax, x + jitter(i, len(sub), 0.3), r[key], r['path'], size=size)
        if sub:
            med = statistics.median(r[key] for r in sub)
            ax.plot([x - bar, x + bar], [med, med], color=TEXT, linewidth=2,
                    solid_capstyle='round', zorder=4)
            if fmt:
                ax.annotate(fmt(med).replace('-', '−'), (x + bar, med), va='center',
                            fontsize=label_fs, color=TEXT, xytext=(3, 0),
                            textcoords='offset points')
    if ref is not None:
        ax.axhline(ref, color=MUTED, linewidth=1, zorder=1)
    if percent:
        ax.yaxis.set_major_formatter(matplotlib.ticker.PercentFormatter(1.0))
    category_axis(ax, [LOCATIONS[label] for label in labels])
    ax.set_ylim(*ylim)
    ax.set_ylabel(ylabel)


def strip(rows, key, ylabel, name, ylim, ref=None, fmt=None, percent=False, loc='lower left'):
    fig, ax = plt.subplots(figsize=(FIG_W, 3.3))
    draw_strip(ax, rows, key, ylabel, ylim, ref=ref and ref[0], fmt=fmt, percent=percent,
               size=40)
    present = [p for p in PATHS if any(r['path'] == p for r in rows)]
    handles = path_handles(present) + [median_handle()] + ([ref_handle(ref[1])] if ref else [])
    ax.legend(handles=handles, loc=loc)
    fig.tight_layout()
    save(fig, name)


def plot_delivery_and_rssi(rows):
    plot_pair(
        lambda ax: draw_strip(ax, rows, 'pdr', 'Delivery ratio', PDR_YLIM, percent=True),
        lambda ax: draw_strip(ax, rows, 'rssi', 'RSSI (dBm)', RSSI_YLIM, ref=SENSITIVITY_DBM),
        '(a) Delivery ratio', '(b) Received signal strength (RSSI)', 'indoor_delivery_rssi')


def main():
    rows = load()
    print(f'{len(rows)} ramp steps from {DATA}')
    plot_map()
    plot_delivery_and_rssi(rows)
    plot_delivered_grid(rows, list(LOCATIONS), NAMES, 3, 'indoor_delivered_vs_offered')
    strip(rows, 'pdr', 'Delivery ratio', 'indoor_delivery', PDR_YLIM,
          fmt=lambda v: f'{v:.0%}', percent=True)
    strip(rows, 'rssi', 'RSSI (dBm)', 'indoor_rssi', RSSI_YLIM,
          ref=(SENSITIVITY_DBM, 'Receiver sensitivity'), fmt=lambda v: f'{v:.0f} dBm',
          loc='upper right')
    strip(rows, 'snr', 'SNR (dB)', 'indoor_snr', (-10, 13),
          ref=(SNR_LIMIT_DB, 'Demodulation limit (SF7)'), fmt=lambda v: f'{v:.1f} dB')


if __name__ == '__main__':
    main()
